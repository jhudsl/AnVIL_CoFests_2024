# Polygenic Risk Score (PRS) Analysis in AnVIL

Led by: Matthew Lebo, Harvard Medical School

AnVIL Outreach coordinator: Elizabeth Humphries
